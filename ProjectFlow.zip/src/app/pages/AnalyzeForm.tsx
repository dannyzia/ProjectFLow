import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Navbar } from '../components/Navbar';
import { IdeSelector } from '../components/IdeSelector';
import { LoadingState } from '../components/LoadingState';
import { ErrorAlert } from '../components/ErrorAlert';
import { ResultsDisplay } from '../components/ResultsDisplay';
import { analyzeProject, getCwd, openFolder } from '../api/client';

export function AnalyzeForm() {
  const navigate = useNavigate();
  const [projectPath, setProjectPath] = useState('');
  const [selectedIdes, setSelectedIdes] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ files_written: string[]; output_path: string } | null>(null);

  const handleUseCwd = async () => {
    try {
      const data = await getCwd();
      setProjectPath(data.cwd);
    } catch (err) {
      setError('Failed to get current directory');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const data = await analyzeProject({
        project_path: projectPath,
        ides: selectedIdes,
      });
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Failed to analyze project');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateAnother = () => {
    setResult(null);
    setProjectPath('');
    setSelectedIdes([]);
    setError(null);
    navigate('/generate');
  };

  const handleOpenFolder = async () => {
    if (result) {
      try {
        await openFolder(result.output_path);
      } catch (err) {
        setError('Failed to open folder');
      }
    }
  };

  const isFormValid = projectPath.trim() && selectedIdes.length > 0;

  // Show results inline
  if (result) {
    return (
      <div className="min-h-screen bg-[#0f172a]">
        <Navbar />
        <div className="max-w-3xl mx-auto px-6 py-16">
          <ResultsDisplay
            filesWritten={result.files_written}
            outputPath={result.output_path}
            onGenerateAnother={handleGenerateAnother}
            onOpenFolder={handleOpenFolder}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <Navbar />
      
      <div className="max-w-3xl mx-auto px-6 py-16">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-white mb-2">
            Smart Analyze
          </h1>
          <p className="text-[#cbd5e1]">
            Point to an existing project on your machine. AI reads your actual code and generates tailored config files.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Section A — Project Folder */}
          <div className="bg-[#1e293b] rounded-[12px] p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-white mb-6">Project Folder</h2>
            
            <div>
              <label htmlFor="projectPath" className="block text-sm font-medium text-[#cbd5e1] mb-2">
                Path to your project <span className="text-[#ef4444]">*</span>
              </label>
              <div className="flex gap-2">
                <input
                  id="projectPath"
                  type="text"
                  value={projectPath}
                  onChange={(e) => setProjectPath(e.target.value)}
                  placeholder="/Users/john/projects/my-app"
                  required
                  className="flex-1 bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={handleUseCwd}
                  className="px-4 py-2.5 bg-[#334155] hover:bg-[#475569] text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
                >
                  Use current directory
                </button>
              </div>
              <p className="text-sm text-gray-500 mt-2">
                AI will read your code files to detect your tech stack and generate tailored configs.
              </p>
            </div>
          </div>

          {/* Section B — Choose Your IDEs */}
          <div className="bg-[#1e293b] rounded-[12px] p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-white mb-6">Choose Your IDEs</h2>
            <IdeSelector selectedIdes={selectedIdes} onChange={setSelectedIdes} />
          </div>

          {/* Error Display */}
          {error && (
            <ErrorAlert message={error} />
          )}

          {/* Generate Button / Loading State */}
          {isLoading ? (
            <LoadingState mode="analyze" />
          ) : (
            <button
              type="submit"
              disabled={!isFormValid}
              className="w-full bg-[#3b82f6] hover:bg-[#2563eb] disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
            >
              🔍 Analyze & Generate
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
