import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingStateProps {
  mode: 'scaffold' | 'analyze';
}

const SCAFFOLD_MESSAGES = [
  'Generating rules...',
  'Building agent configs...',
  'Writing files...',
];

const ANALYZE_MESSAGES = [
  'Scanning project files...',
  'Detecting tech stack...',
  'Generating configs...',
  'Writing files...',
];

export function LoadingState({ mode }: LoadingStateProps) {
  const [messageIndex, setMessageIndex] = useState(0);
  const messages = mode === 'scaffold' ? SCAFFOLD_MESSAGES : ANALYZE_MESSAGES;
  
  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    }, 1500);
    
    return () => clearInterval(interval);
  }, [messages.length]);
  
  return (
    <div className="flex items-center justify-center gap-3 py-8">
      <Loader2 className="w-5 h-5 text-[#3b82f6] animate-spin" />
      <span className="text-[#cbd5e1]">{messages[messageIndex]}</span>
    </div>
  );
}
