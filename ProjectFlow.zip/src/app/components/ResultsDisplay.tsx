import { CheckCircle2, FolderOpen } from 'lucide-react';

interface ResultsDisplayProps {
  filesWritten: string[];
  outputPath: string;
  onGenerateAnother: () => void;
  onOpenFolder: () => void;
}

export function ResultsDisplay({ 
  filesWritten, 
  outputPath, 
  onGenerateAnother, 
  onOpenFolder 
}: ResultsDisplayProps) {
  // Group files by IDE
  const groupedFiles = filesWritten.reduce((acc, file) => {
    const ideMatch = file.match(/^\.([^/]+)\//);
    const ide = ideMatch ? ideMatch[1] : 'other';
    if (!acc[ide]) acc[ide] = [];
    acc[ide].push(file);
    return acc;
  }, {} as Record<string, string[]>);
  
  return (
    <div className="bg-[#1e293b] rounded-[12px] p-8 border border-gray-700">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-[#22c55e]/10 rounded-full mb-4">
          <CheckCircle2 className="w-8 h-8 text-[#22c55e]" />
        </div>
        <h2 className="text-2xl font-semibold text-white mb-2">
          ✅ Done!
        </h2>
        <p className="text-[#cbd5e1]">
          Files written to: <span className="text-white font-mono text-sm">{outputPath}</span>
        </p>
      </div>
      
      <div className="space-y-6 mb-8">
        {Object.entries(groupedFiles).map(([ide, files]) => (
          <div key={ide}>
            <h3 className="text-sm font-medium text-[#cbd5e1] mb-2 uppercase">
              {ide}
            </h3>
            <div className="space-y-1">
              {files.map((file, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
                  <span className="text-white font-mono">{file}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="flex gap-3">
        <button
          onClick={onGenerateAnother}
          className="flex-1 bg-[#1e293b] hover:bg-[#334155] text-white border border-gray-700 px-6 py-3 rounded-lg font-medium transition-colors"
        >
          Generate Another
        </button>
        <button
          onClick={onOpenFolder}
          className="flex-1 bg-[#3b82f6] hover:bg-[#2563eb] text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
        >
          <FolderOpen size={20} />
          Open Folder
        </button>
      </div>
    </div>
  );
}
